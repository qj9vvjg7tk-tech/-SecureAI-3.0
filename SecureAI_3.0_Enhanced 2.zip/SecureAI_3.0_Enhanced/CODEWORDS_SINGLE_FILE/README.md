# CodeWords Deployment
This single file is the version deployed on CodeWords.
Service ID: secureai_3_05648c7f
URL: https://codewords.agemo.ai/run/secureai_3_05648c7f/app/
